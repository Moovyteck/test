<?php
/**
 * @package     VikChannelManager
 * @subpackage  com_vikchannelmanager
 * @author      e4j - Extensionsforjoomla.com
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All rights reserved.
 * @license     GNU General Public License version 2 or later
 * @link        https://e4jconnect.com - https://vikwp.com
 */

defined('_JEXEC') OR die('Restricted Area');

class VikChannelManagerControllerBulkaction extends JControllerAdmin
{
	/**
	 * AJAX endpoint originally introduced for the Bulk Action - Rates Upload to preload
	 * the assets for specific channels. Introduced for Vrbo API to generate an updated
	 * copy of the XML files for lodging rate and cache them with the latest rates.
	 * 
	 * @return 	void
	 */
	public function rates_preload_channel_asset()
	{
		// allow support for both single and multiple values
		$asset_signs = VikRequest::getVar('assets', array(), 'request', 'array');
		$asset_sign  = VikRequest::getString('asset', '', 'request');

		if (empty($asset_signs) && empty($asset_sign)) {
			VBOHttpDocument::getInstance()->close(500, 'Missing assets to preload');
		}

		// make sure to always have an array of asset signs
		if (!empty($asset_signs)) {
			$preload_assets = $asset_signs;
		} else {
			$preload_assets = [$asset_sign];
		}

		// assets preloaded
		$assets_preloaded = 0;

		foreach ($preload_assets as $asset_sign) {
			list($channel_id, $room_id) = explode('-', $asset_sign);

			$channel = VikChannelManager::getChannel($channel_id);
			if (!$channel || $channel['uniquekey'] != VikChannelManagerConfig::VRBOAPI) {
				continue;
			}

			try {
				// attempt to generate an XML document with no output
				$xml_str = VCMVrboXml::getInstance($app = null, $cache_allowed = false)->processDocument('listing_rate', $channel, $room_id, $render = false);
				if ($xml_str) {
					// increase counter
					$assets_preloaded++;
				}
			} catch (Exception $e) {
				// exit with the error returned
				VBOHttpDocument::getInstance()->close(500, $e->getMessage());
			}
		}

		// return a JSON response result
		VBOHttpDocument::getInstance()->json([
			'status'  => $assets_preloaded,
		]);
	}

	/**
	 * AJAX endpoint to count the rooms mapped for a specific channel and account.
	 * 
	 * @return 	void
	 * 
	 * @since 	1.8.16
	 */
	public function count_rooms_mapped()
	{
		$account = VikRequest::getString('account', '', 'request');
		$channel = VikRequest::getInt('channel', 0, 'request');

		$mapping_data = VikChannelManager::getChannelAccountsMapped($channel, $get_rooms = true);

		$account_rooms = $mapping_data && isset($mapping_data[$account]) && is_array($mapping_data[$account]) ? count($mapping_data[$account]) : 0;

		// return a JSON response result
		VBOHttpDocument::getInstance()->json([
			'count' => $account_rooms,
		]);
	}
}
