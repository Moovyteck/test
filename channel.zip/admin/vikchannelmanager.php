<?php
/**
 * @package     VikChannelManager
 * @subpackage  com_vikchannelmanager
 * @author      e4j - Extensionsforjoomla.com
 * @copyright   Copyright (C) 2018 e4j - Extensionsforjoomla.com. All rights reserved.
 * @license     GNU General Public License version 2 or later
 * @link        https://e4jconnect.com
 */

defined('_JEXEC') OR die('Restricted access');

/* --- Joomla portability --- */
include(JPATH_SITE . DIRECTORY_SEPARATOR . "components" . DIRECTORY_SEPARATOR . "com_vikchannelmanager" . DIRECTORY_SEPARATOR . "helpers" . DIRECTORY_SEPARATOR . "adapter" . DIRECTORY_SEPARATOR . "defines.php");
include(JPATH_SITE . DIRECTORY_SEPARATOR . "components" . DIRECTORY_SEPARATOR . "com_vikchannelmanager" . DIRECTORY_SEPARATOR . "helpers" . DIRECTORY_SEPARATOR . "adapter" . DIRECTORY_SEPARATOR . "request.php");
include(JPATH_SITE . DIRECTORY_SEPARATOR . "components" . DIRECTORY_SEPARATOR . "com_vikchannelmanager" . DIRECTORY_SEPARATOR . "helpers" . DIRECTORY_SEPARATOR . "adapter" . DIRECTORY_SEPARATOR . "json.php");
include(JPATH_SITE . DIRECTORY_SEPARATOR . "components" . DIRECTORY_SEPARATOR . "com_vikchannelmanager" . DIRECTORY_SEPARATOR . "helpers" . DIRECTORY_SEPARATOR . "adapter" . DIRECTORY_SEPARATOR . "error.php");
/* --- */

defined('VIKCHANNELMANAGER_SOFTWARE_VERSION') or define('VIKCHANNELMANAGER_SOFTWARE_VERSION', '1.8.27');

// Access check.
if (!JFactory::getUser()->authorise('core.manage', 'com_vikchannelmanager')) {
	return VikError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
}

// require helper files
require_once(VCM_ADMIN_PATH . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'helper.php');
require_once(VCM_SITE_PATH . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'lib.vikchannelmanager.php');
require_once(VCM_SITE_PATH . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'vcm_config.php');

/**
 * VBO Internal libraries autoloader.
 * 
 * @since 		1.8.4
 * 
 * @requires 	VBO >= 1.15.0
 */
$vbo_src_al_path = VBO_ADMIN_PATH . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'src' . DIRECTORY_SEPARATOR . 'autoload.php';
if (is_file($vbo_src_al_path)) {
	require_once $vbo_src_al_path;
}

/**
 * Normalize db driver and script declarations (if necessary).
 * 
 * @since 	1.7.5
 */
VikChannelManager::normalizeExecution();

// import joomla controller library
jimport('joomla.application.component.controller');

new OrderingManager('com_vikchannelmanager', 'vcmordcolumn', 'vcmordtype');

// Trigger reports
VikChannelManager::notifyReportsData();

// Trigger reminders
VikChannelManager::checkSubscriptionReminder();

// Trigger auto bulk actions
VikChannelManager::autoBulkActions();

// Trigger schedules for failed data transmission
VCMRequestScheduler::getInstance()->retry();

// monitor ongoing and expired pending lock records
VCMRequestAvailability::getInstance()->monitorPendingLocks();

// monitor guest messages that require an automatic response
VCMChatAutoresponder::getInstance()->watchSchedules();

// Add CSS file for all pages
VCM::load_css_js();

// Get an instance of the controller
$controller = JControllerUI::getInstance('VikChannelManager');

// Perform the Request task
$controller->execute(VikRequest::getCmd('task'));

// Redirect if set by the controller
$controller->redirect();

/**
 * Load the Web App Manifest JSON file.
 * 
 * @requires 	VBO >= 1.16.5
 * 
 * @since 		1.8.20
 */
if (class_exists('VBOWebappManifest')) {
	VBOWebappManifest::load();
}
