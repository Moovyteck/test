<?php
/**
 * @package     VikChannelManager
 * @subpackage  com_vikchannelmanager
 * @author      E4J srl
 * @copyright   Copyright (C) 2023 e4j - Extensionsforjoomla.com. All rights reserved.
 * @license     GNU General Public License version 2 or later
 * @link        https://e4jconnect.com
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * This class is automatically loaded by Joomla to
 * invoke this method when updating the component.
 * 
 * @joomlaonly
 * 
 * @since 	1.8.15
 */
class VikChannelManagerHelper
{
	/**
	 * Method to add parameters to the update extra query, but we use it
	 * to perform a redirection to the actual update URL.
	 *
	 * @param   Update  &$update  An update definition
	 * @param   JTable  &$table   The update instance from the database
	 *
	 * @return  void
	 */
	public static function prepareUpdate(&$update, &$table)
	{
		$app = JFactory::getApplication();

		// redirect the page to the endpoint URL that will actually download and install the update
		$app->redirect('index.php?option=com_vikchannelmanager&task=update_program&force_check=1');
		$app->close();
	}
}
