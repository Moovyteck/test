<?php
/** 
 * @package     VikChannelManager
 * @subpackage  core
 * @author      E4J s.r.l.
 * @copyright   Copyright (C) 2023 E4J s.r.l. All Rights Reserved.
 * @license     http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @link        https://vikwp.com
 */

// No direct access
defined('_JEXEC') OR die('Restricted Area');

/**
 * Detects the platform on which the system is running.
 * 
 * @since 	1.8.16
 */
final class VCMPlatformDetection
{
	/**
	 * @var 	string
	 */
	private static $platform = '';

	/**
	 * Tells whether the current platform is WordPress.
	 * 
	 * @return 	bool
	 */
	public static function isWordPress()
	{
		if (!static::$platform) {
			static::detect();
		}

		return (static::$platform === 'wordpress');
	}

	/**
	 * Tells whether the current platform is Joomla.
	 * 
	 * @return 	bool
	 */
	public static function isJoomla()
	{
		if (!static::$platform) {
			static::detect();
		}

		return (static::$platform === 'joomla');
	}

	/**
	 * Detects the name of the platform on which we are running the software.
	 * 
	 * @return 	void
	 */
	private static function detect()
	{
		if (defined('ABSPATH') && function_exists('wp_die')) {
			static::$platform = 'wordpress';
		} else {
			static::$platform = 'joomla';
		}
	}
}
