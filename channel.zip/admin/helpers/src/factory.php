<?php
/**
 * @package     VikChannelManager
 * @subpackage  com_vikchannelmanager
 * @author      e4j - Extensionsforjoomla.com
 * @copyright   Copyright (C) 2022 e4j - Extensionsforjoomla.com. All rights reserved.
 * @license     GNU General Public License version 2 or later
 * @link        https://e4jconnect.com - https://e4j.com
 */

// No direct access
defined('_JEXEC') or die('Restricted access');

/**
 * Factory application class.
 *
 * @since 	1.8.11
 */
final class VCMFactory
{
	/**
	 * Application configuration handler.
	 *
	 * @var VCMConfigRegistry
	 */
	private static $config;

	/**
	 * Application platform handler.
	 *
	 * @var VCMPlatformInterface
	 */
	private static $platform;

	/**
	 * Class constructor.
	 * @private This object cannot be instantiated. 
	 */
	private function __construct()
	{
		// never called
	}

	/**
	 * Class cloner.
	 * @private This object cannot be cloned.
	 */
	private function __clone()
	{
		// never called
	}

	/**
	 * Returns the current configuration object.
	 *
	 * @return 	VCMConfigRegistry
	 */
	public static function getConfig()
	{
		// check if config class is already instantiated
		if (is_null(static::$config))
		{
			// cache instantiation
			static::$config = new VCMConfigRegistryDatabase([
				'db' => JFactory::getDbo(),
			]);
		}

		return static::$config;
	}

	/**
	 * Returns the current platform handler.
	 *
	 * @return 	VCMPlatformInterface
	 */
	public static function getPlatform()
	{
		// check if platform class is already instantiated
		if (is_null(static::$platform))
		{
			if (VCMPlatformDetection::isWordPress())
			{
				// running WordPress platform
				static::$platform = new VCMPlatformOrgWordpress();
			}
			else
			{
				// running Joomla platform
				static::$platform = new VCMPlatformOrgJoomla();
			}
		}

		return static::$platform;
	}
}
