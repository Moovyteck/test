<?php
/**
 * @package     VikChannelManager
 * @subpackage  com_vikchannelmanager
 * @author      E4J srl
 * @copyright   Copyright (C) 2023 E4J srl. All rights reserved.
 * @license     GNU General Public License version 2 or later
 * @link        https://e4jconnect.com - https://vikwp.com
 */

defined('_JEXEC') or die('Restricted access');

/**
 * OTA Booking helper. Used to detect specific OTA reservations.
 * 
 * @since 	1.8.16
 */
final class VCMOtaBooking extends JObject
{
	/**
	 * The singleton instance of the class.
	 *
	 * @var  VCMOtaBooking
	 */
	private static $instance = null;

	/**
	 * Proxy to construct the object.
	 * 
	 * @param 	array|object  $data  optional data to bind.
	 * @param 	boolean 	  $anew  true for forcing a new instance.
	 * 
	 * @return 	self
	 */
	public static function getInstance($data = [], $anew = false)
	{
		if (is_null(static::$instance) || $anew) {
			static::$instance = new static($data);
		}

		return static::$instance;
	}

	/**
	 * Returns a list of channels that can be assigned to a specific booking.
	 * Originally introduced to allow admins to manually assign a website
	 * reservation to a channel like Vrbo API so that it will appear in the BUS.
	 * 
	 * @return 	array 	list of associative channels eligible for the booking.
	 */
	public function getChannelsAssignable()
	{
		$bid 	  = $this->get('id');
		$channel  = $this->get('channel');
		$ota_bid  = $this->get('idorderota');
		$status   = $this->get('status', '');
		$checkout = $this->get('checkout', 0);

		if (empty($bid) || !empty($channel) || !empty($ota_bid)) {
			// only website reservations are allowed
			return [];
		}

		if ($this->get('closure', 0) || $this->get('total', 0) <= 0) {
			// should not be a closure and the total amount should be greater than zero
			return [];
		}

		$max_checkout_past = strtotime('-46 days');

		if ($status != 'confirmed' || $checkout < $max_checkout_past) {
			// reservation not eligible
			return [];
		}

		if (!VikChannelManager::channelHasRoomsMapped(VikChannelManagerConfig::VRBOAPI)) {
			// the channel Vrbo API must be active and configured
			return [];
		}

		return [
			'vrboapi_vrboapi' => 'Vrbo',
		];
	}

	/**
	 * Performs a request to the E4jConnect servers to decode the
	 * OTA credit card (partial) details that were previously
	 * stored upon receiving a new reservation.
	 * 
	 * @return 	array 	associative array with the CC details or error message.
	 * 
	 * @since 	1.8.19
	 */
	public function decodeCreditCardDetails()
	{
		$apikey = VCMFactory::getConfig()->get('apikey', '');

		$channel_source = $this->get('channel_source');
		$ota_id 		= $this->get('ota_id');

		if (!$apikey || !$channel_source || !$ota_id) {
			return [
				'error' => 'Missing values to request the credit card details.',
			];
		}

		$e4jc_url = "https://e4jconnect.com/channelmanager/?r=pcid&c=generic";

		$xml = '<?xml version="1.0" encoding="UTF-8"?>
<!-- VikChannelManager PCID Request e4jConnect.com - Module Extensionsforjoomla.com -->
<PCIDataRQ xmlns="http://www.e4jconnect.com/schemas/pcidrq">
	<Notify client="' . JUri::root() . '"/>
	<Api key="' . $apikey . '"/>
	<Channel source="' . $channel_source . '"/>
	<Booking otaid="' . $ota_id . '"/>
</PCIDataRQ>';

		$e4jC = new E4jConnectRequest($e4jc_url);
		$e4jC->setPostFields($xml);
		$e4jC->slaveEnabled = true;
		$rs = $e4jC->exec();
		if ($e4jC->getErrorNo()) {
			return [
				'error' => 'Error ' . @curl_error($e4jC->getCurlHeader()),
			];
		}

		if (substr($rs, 0, 9) == 'e4j.error' || substr($rs, 0, 11) == 'e4j.warning') {
			return [
				'error' => VikChannelManager::getErrorFromMap($rs),
			];
		}

		// the salt is hashed twice
		$cipher = VikChannelManager::loadCypherFramework(md5($apikey . "e4j" . $ota_id));

		// @array credit card response
		// [card_number] @string : 4242 4242 4242 ****
		// [cvv] @int : 123
		$credit_card_response = json_decode($cipher->decrypt($rs), true);
		$credit_card_response = !is_array($credit_card_response) ? [] : $credit_card_response;

		if (!$credit_card_response) {
			return [
				'error' => 'Could not decode credit card details, which may not be available.',
			];
		}

		// return the whole credit card details associative array with decoded information
		return $credit_card_response;
	}
}
