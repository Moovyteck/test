<?php
/**
 * @package     VikChannelManager
 * @subpackage  com_vikchannelmanager
 * @author      e4j - Extensionsforjoomla.com
 * @copyright   Copyright (C) 2018 e4j - Extensionsforjoomla.com. All rights reserved.
 * @license     GNU General Public License version 2 or later
 * @link        https://e4jconnect.com
 */

defined('_JEXEC') OR die('Restricted Area');

echo '<p style="text-align: center; margin: 100px 0 100px 0; padding: 5px; font-weight: bold;">Vik Channel Manager - Powered by <a href="https://extensionsforjoomla.com/">e4j - Extensionsforjoomla.com</a></p>';

?>