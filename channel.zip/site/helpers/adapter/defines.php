<?php
/**
 * @package     VikChannelManager
 * @subpackage  com_vikchannelmanager
 * @author      e4j - Extensionsforjoomla.com
 * @copyright   Copyright (C) 2018 e4j - Extensionsforjoomla.com. All rights reserved.
 * @license     GNU General Public License version 2 or later
 * @link        https://e4jconnect.com
 */

defined('_JEXEC') OR die('Restricted Area');

/* URI Constants for admin and site sections (with trailing slash) */
defined('VBO_ADMIN_URI') or define('VBO_ADMIN_URI', JUri::root().'administrator/components/com_vikbooking/');
defined('VBO_SITE_URI') or define('VBO_SITE_URI', JUri::root().'components/com_vikbooking/');
defined('VBO_ADMIN_URI_REL') or define('VBO_ADMIN_URI_REL', './administrator/components/com_vikbooking/');
defined('VBO_SITE_URI_REL') or define('VBO_SITE_URI_REL', './components/com_vikbooking/');
defined('VCM_ADMIN_URI') or define('VCM_ADMIN_URI', JUri::root().'administrator/components/com_vikchannelmanager/');
defined('VCM_SITE_URI') or define('VCM_SITE_URI', JUri::root().'components/com_vikchannelmanager/');

/* Path Constants for admin and site sections (with NO trailing directory separator) */
defined('VBO_ADMIN_PATH') or define('VBO_ADMIN_PATH', JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_vikbooking');
defined('VBO_SITE_PATH') or define('VBO_SITE_PATH', JPATH_SITE . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_vikbooking');
defined('VCM_ADMIN_PATH') or define('VCM_ADMIN_PATH', JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_vikchannelmanager');
defined('VCM_SITE_PATH') or define('VCM_SITE_PATH', JPATH_SITE . DIRECTORY_SEPARATOR . 'components' . DIRECTORY_SEPARATOR . 'com_vikchannelmanager');

/* Other Constants that may not be available in the framework */
defined('JPATH_COMPONENT_SITE') or define('JPATH_COMPONENT_SITE', JPATH_SITE . DIRECTORY_SEPARATOR . 'com_vikchannelmanager');
defined('JPATH_COMPONENT_ADMINISTRATOR') or define('JPATH_COMPONENT_ADMINISTRATOR', JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'com_vikchannelmanager');
defined('DS') or define('DS', DIRECTORY_SEPARATOR);

/**
 * We use these language constants for compatibility with other frameworks.
 * 
 * @since 	1.7.1
 */
defined('VIKCHANNELMANAGER_SITE_LANG') or define('VIKCHANNELMANAGER_SITE_LANG', JPATH_SITE);
defined('VIKCHANNELMANAGER_ADMIN_LANG') or define('VIKCHANNELMANAGER_ADMIN_LANG', JPATH_ADMINISTRATOR);

/**
 * We define the base path constant for the Vik Booking upload
 * dir used to upload the customer documents onto the sub-dirs.
 * 
 * @since 	1.7.4
 */
defined('VBO_CUSTOMERS_PATH') or define('VBO_CUSTOMERS_PATH', VBO_ADMIN_PATH . DIRECTORY_SEPARATOR . 'resources' . DIRECTORY_SEPARATOR . 'customers');
defined('VBO_CUSTOMERS_URI') or define('VBO_CUSTOMERS_URI', VBO_ADMIN_URI . 'resources/customers/');

/**
 * Make sure the software version constant is defined in case VCM is called by VBO.
 * 
 * @joomlaonly
 * 
 * @since 	1.8.24
 */
defined('VIKCHANNELMANAGER_SOFTWARE_VERSION') or define('VIKCHANNELMANAGER_SOFTWARE_VERSION', '1.8.27');

/* Adapter for Controller and View Classes for compatiblity with the various frameworks */
if (!class_exists('JControllerUI') && class_exists('JControllerLegacy')) {

	class JViewUI extends JViewLegacy {
		/* adapter for JViewLegacy */
	}

	class JControllerUI extends JControllerLegacy {
		/* adapter for JControllerLegacy */
	}

} elseif (!class_exists('JControllerUI') && class_exists('JController')) {

	class JViewUI extends JView {
		/* adapter for JView */
	}

	class JControllerUI extends JController {
		/* adapter for JController */
	}

}
